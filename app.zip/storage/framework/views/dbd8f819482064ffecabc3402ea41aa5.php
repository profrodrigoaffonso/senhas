<div class="row">
    Senhas chamadas
</div>
<div class="row">
<?php $__currentLoopData = $chamadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chamada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col"><?php echo e($chamada->senha); ?><br><?php echo e($chamada->nome); ?></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\wamp64\www\senhas3\resources\views/tela/anteriores.blade.php ENDPATH**/ ?>